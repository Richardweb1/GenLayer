from genlayer import *

@gl.contract
class CryptoQuest:
    """
    CryptoQuest - An AI-Powered Adventure Game on GenLayer
    
    A text-based adventure game where the AI generates dynamic responses
    to player actions, creating unique gameplay experiences.
    """
    
    players: dict[str, dict]
    game_started: bool
    
    def __init__(self):
        self.players = {}
        self.game_started = True
    
    @gl.public.write
    def start_game(self, player_name: str) -> dict:
        """
        Start a new game for a player
        """
        player_address = gl.message_sender_address
        
        if player_address in self.players:
            return {
                "success": False,
                "message": f"Player {player_name} already has an active game!"
            }
        
        self.players[player_address] = {
            "name": player_name,
            "health": 100,
            "gold": 50,
            "inventory": ["torch", "map"],
            "location": "village_square",
            "score": 0,
            "story": "You wake up in a mysterious village square, the morning sun casting long shadows..."
        }
        
        return {
            "success": True,
            "message": f"Welcome to CryptoQuest, {player_name}!",
            "game_state": self.players[player_address]
        }
    
    @gl.public.write
    async def take_action(self, action: str) -> dict:
        """
        Player takes an action in the game - AI generates the response
        """
        player_address = gl.message_sender_address
        
        if player_address not in self.players:
            return {
                "success": False,
                "message": "You must start a game first! Call start_game()"
            }
        
        player = self.players[player_address]
        
        # Use AI to generate dynamic story response
        prompt = f"""
        You are the game master for CryptoQuest, a fantasy adventure game.
        
        Current Player State:
        - Name: {player['name']}
        - Health: {player['health']}
        - Gold: {player['gold']}
        - Inventory: {', '.join(player['inventory'])}
        - Location: {player['location']}
        - Current Story: {player['story']}
        
        Player Action: {action}
        
        Generate a creative response to the player's action. Your response should:
        1. Describe what happens (2-3 sentences max)
        2. Update game state if needed (format: HEALTH:+10 or GOLD:-5 or ITEM:+sword)
        3. Be engaging and maintain fantasy adventure theme
        
        Format your response as:
        STORY: [your story description]
        CHANGES: [any game state changes like HEALTH:+10, GOLD:+20, ITEM:+sword]
        """
        
        try:
            result = await gl.exec_prompt(prompt)
            
            # Parse AI response
            story_part = ""
            changes = ""
            
            if "STORY:" in result:
                parts = result.split("CHANGES:")
                story_part = parts[0].replace("STORY:", "").strip()
                if len(parts) > 1:
                    changes = parts[1].strip()
            else:
                story_part = result
            
            # Apply game state changes
            if changes:
                if "HEALTH:" in changes:
                    health_change = int(changes.split("HEALTH:")[1].split()[0])
                    player['health'] = max(0, min(100, player['health'] + health_change))
                
                if "GOLD:" in changes:
                    gold_change = int(changes.split("GOLD:")[1].split()[0])
                    player['gold'] = max(0, player['gold'] + gold_change)
                
                if "ITEM:+" in changes:
                    item = changes.split("ITEM:+")[1].split()[0]
                    if item not in player['inventory']:
                        player['inventory'].append(item)
                
                if "ITEM:-" in changes:
                    item = changes.split("ITEM:-")[1].split()[0]
                    if item in player['inventory']:
                        player['inventory'].remove(item)
            
            # Update player score
            player['score'] += 10
            player['story'] = story_part
            
            # Check if player died
            if player['health'] <= 0:
                final_score = player['score']
                del self.players[player_address]
                return {
                    "success": True,
                    "game_over": True,
                    "message": "You have died! Game Over.",
                    "final_score": final_score,
                    "story": story_part
                }
            
            return {
                "success": True,
                "story": story_part,
                "game_state": player
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"AI Error: {str(e)}"
            }
    
    @gl.public.view
    def get_player_stats(self) -> dict:
        """
        Get current player's statistics
        """
        player_address = gl.message_sender_address
        
        if player_address not in self.players:
            return {
                "success": False,
                "message": "No active game found"
            }
        
        return {
            "success": True,
            "player": self.players[player_address]
        }
    
    @gl.public.view
    def get_leaderboard(self) -> dict:
        """
        Get top 10 players by score
        """
        leaderboard = []
        for address, player in self.players.items():
            leaderboard.append({
                "name": player['name'],
                "score": player['score'],
                "health": player['health'],
                "gold": player['gold']
            })
        
        # Sort by score
        leaderboard.sort(key=lambda x: x['score'], reverse=True)
        
        return {
            "success": True,
            "leaderboard": leaderboard[:10]
        }
    
    @gl.public.write
    def reset_game(self) -> dict:
        """
        Reset player's game (start over)
        """
        player_address = gl.message_sender_address
        
        if player_address in self.players:
            player_name = self.players[player_address]['name']
            del self.players[player_address]
            return {
                "success": True,
                "message": f"Game reset for {player_name}. Call start_game() to play again!"
            }
        
        return {
            "success": False,
            "message": "No active game to reset"
        }
