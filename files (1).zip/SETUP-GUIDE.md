# 🚀 Quick Setup Guide - Submit to GenLayer Portal

## What You Have

✅ **CryptoQuest Game Contract** (`cryptoquest.py`)  
✅ **Web Frontend** (`cryptoquest-frontend.html`)  
✅ **Documentation** (`README.md`)  
✅ **Profile README** (`PROFILE-README.md`)

---

## Step 1: Create GitHub Repository

1. Go to [https://github.com/new](https://github.com/new)
2. Repository name: `cryptoquest` (or any name you like)
3. Description: "AI-Powered Adventure Game on GenLayer Blockchain"
4. Make it **Public**
5. Click "Create repository"

---

## Step 2: Upload Your Files

### Option A: Via GitHub Web Interface (Easiest)

1. In your new repository, click "uploading an existing file"
2. Drag and drop these files:
   - `cryptoquest.py`
   - `cryptoquest-frontend.html` (rename to `index.html` for GitHub Pages)
   - `README.md`
3. Commit with message: "Initial commit - CryptoQuest game"

### Option B: Via Git CLI

```bash
# Initialize git
git init
git add .
git commit -m "Initial commit - CryptoQuest game"

# Connect to your repo
git remote add origin https://github.com/Richardweb1/cryptoquest.git
git branch -M main
git push -u origin main
```

---

## Step 3: Update Your GitHub Profile

1. Create a **special repository** with your username:
   - Repository name: `Richardweb1` (same as your username!)
   - Make it **Public**
   - Add a README
2. Replace the README content with `PROFILE-README.md`
3. This will display on your GitHub profile page!

---

## Step 4: Deploy to GenLayer Testnet

### A. Get Testnet Setup

1. **Install MetaMask**: [https://metamask.io/](https://metamask.io/)

2. **Add GenLayer Testnet** to MetaMask:
   - Network Name: `GenLayer Testnet Bradbury`
   - RPC URL: Get from [GenLayer Studio](https://studio.genlayer.com/)
   - Chain ID: (shown in Studio when connecting)
   - Currency Symbol: `GEN`

3. **Get Test Tokens**:
   - Go to: [https://testnet-faucet.genlayer.foundation/](https://testnet-faucet.genlayer.foundation/)
   - Enter your wallet address
   - Solve captcha and request tokens

### B. Deploy Contract

1. Open [GenLayer Studio](https://studio.genlayer.com/)
2. Connect your MetaMask wallet
3. Create new contract
4. Copy/paste `cryptoquest.py` content
5. Click "Deploy" (▶ button)
6. Confirm transaction in MetaMask
7. **Save your contract address!**

### C. Update Frontend

1. Open `index.html` (your frontend file)
2. Find line 287: `const CONTRACT_ADDRESS = "YOUR_CONTRACT_ADDRESS_HERE";`
3. Replace with your actual contract address
4. Commit and push changes to GitHub

---

## Step 5: Enable GitHub Pages (Host Frontend)

1. Go to your repository settings
2. Click "Pages" in the left sidebar
3. Under "Source", select "main" branch
4. Click "Save"
5. Your game will be live at: `https://richardweb1.github.io/cryptoquest/`

---

## Step 6: Submit to GenLayer Portal

1. Go to [https://portal.genlayer.foundation/#/builders](https://portal.genlayer.foundation/#/builders)
2. Connect your wallet (same one used for deployment)
3. Click "Submit Project" or "Add Builder"
4. Fill in the form:
   - **Project Name**: CryptoQuest
   - **Description**: AI-Powered Adventure Game - Dynamic storytelling using LLM consensus
   - **GitHub URL**: `https://github.com/Richardweb1/cryptoquest`
   - **Live Demo**: `https://richardweb1.github.io/cryptoquest/`
   - **Contract Address**: [Your deployed contract address]
   - **Category**: Game / Entertainment
5. Submit!

---

## 📋 Checklist Before Submitting

- [ ] Contract deployed on GenLayer Testnet
- [ ] Contract address saved and added to frontend
- [ ] GitHub repository created and public
- [ ] README.md uploaded and complete
- [ ] Frontend hosted on GitHub Pages
- [ ] Tested the game (can start and play)
- [ ] Profile README created (optional but recommended)

---

## 🎯 What Makes Your Submission Stand Out

✨ **Unique Use Case**: First AI-powered adventure game on GenLayer  
🤖 **AI Integration**: Uses `gl.exec_prompt()` for dynamic content  
🎮 **Playable Demo**: Fully functional frontend  
📚 **Documentation**: Complete README with instructions  
💻 **Open Source**: All code available on GitHub  

---

## 🔍 Important Notes

1. **Keep your contract address safe** - you'll need it for the frontend
2. **Test your game** before submitting to the portal
3. **Update README** with your deployed contract address and live demo URL
4. Make sure GitHub Pages is working before submitting

---

## 🆘 Troubleshooting

### Contract won't deploy?
- Check you have testnet GEN tokens
- Make sure MetaMask is connected to GenLayer Testnet
- Try refreshing GenLayer Studio

### Frontend not working?
- Verify contract address is correct in `index.html`
- Check browser console for errors (F12)
- Make sure MetaMask is unlocked

### GitHub Pages not loading?
- Wait 5-10 minutes after enabling (it takes time to build)
- Check repository settings > Pages for build status
- Make sure repository is public

---

## 📞 Support

- **GenLayer Discord**: Join for community help
- **GenLayer Docs**: [https://docs.genlayer.com/](https://docs.genlayer.com/)
- **GenLayer Portal**: [https://portal.genlayer.foundation/](https://portal.genlayer.foundation/)

---

## 🎉 You're Ready!

Follow these steps and you'll have:
- ✅ A professional GitHub profile
- ✅ A deployed game on GenLayer
- ✅ A live demo people can play
- ✅ A submission to the GenLayer builders portal

**Good luck with your submission!** 🚀

---

*Questions? Open an issue in your GitHub repo or reach out to the GenLayer community!*
